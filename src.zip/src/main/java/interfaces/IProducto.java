package interfaces;

import modelo.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
//IMPLEMENTACION DE LA INTERFACE IPERSONA QUE HEREDA LA CLASE JpaRepository
public interface IProducto extends JpaRepository<Producto, Integer>{
	
}
