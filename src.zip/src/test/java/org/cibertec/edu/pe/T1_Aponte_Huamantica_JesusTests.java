package org.cibertec.edu.pe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class T1_Aponte_Huamantica_JesusTests {

	@Test
	void contextLoads() {
	}

}
